-- ============================================================
-- SCRIPT COMPLETO: E-COMMERCE & MARKETPLACE (TEMA 1)
-- ============================================================
DROP DATABASE IF EXISTS ecommerce_db;
CREATE DATABASE ecommerce_db;
USE ecommerce_db;
CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

-- Tabelas
CREATE TABLE CLIENTE (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ENDERECO_ENTREGA (
    id_endereco INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    logradouro VARCHAR(150) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES CLIENTE(id_cliente) ON DELETE CASCADE
);

CREATE TABLE CATEGORIA (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nome_categoria VARCHAR(50) NOT NULL
);

CREATE TABLE PRODUTO (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    id_categoria INT NOT NULL,
    nome_produto VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    FOREIGN KEY (id_categoria) REFERENCES CATEGORIA(id_categoria)
);

CREATE TABLE FORMA_PAGAMENTO (
    id_forma_pagamento INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(50) NOT NULL
);

CREATE TABLE PEDIDO (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_endereco INT NOT NULL,
    data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
    status_pedido VARCHAR(30) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES CLIENTE(id_cliente),
    FOREIGN KEY (id_endereco) REFERENCES ENDERECO_ENTREGA(id_endereco)
);

CREATE TABLE ITEM_PEDIDO (
    id_item INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES PEDIDO(id_pedido) ON DELETE CASCADE,
    FOREIGN KEY (id_produto) REFERENCES PRODUTO(id_produto)
);

CREATE TABLE PAGAMENTO (
    id_pagamento INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_forma_pagamento INT NOT NULL,
    valor_pago DECIMAL(10,2) NOT NULL,
    data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pedido) REFERENCES PEDIDO(id_pedido),
    FOREIGN KEY (id_forma_pagamento) REFERENCES FORMA_PAGAMENTO(id_forma_pagamento)
);

-- Carga Inicial (INSERTs)
INSERT INTO CLIENTE (nome, email, cpf, data_cadastro) VALUES
('Alan Rosa', 'alan@email.com', '111.222.333-44', '2026-01-10 10:00:00'),
('Beatriz Silva', 'beatriz@email.com', '222.333.444-55', '2026-02-15 14:30:00'),
('Carlos Eduardo', 'carlos@email.com', '333.444.555-66', '2026-03-01 09:15:00'),
('Daniela Souza', 'daniela@email.com', '444.555.666-77', '2026-03-10 18:20:00');

INSERT INTO ENDERECO_ENTREGA (id_cliente, logradouro, cidade, estado, cep) VALUES
(1, 'Rua das Flores, 123', 'Mogi das Cruzes', 'SP', '08700-000'),
(2, 'Av. Paulista, 1000', 'São Paulo', 'SP', '01310-100'),
(3, 'Rua Central, 45', 'Campinas', 'SP', '13000-000'),
(4, 'Praça da Sé, 10', 'São Paulo', 'SP', '01001-000');

INSERT INTO CATEGORIA (nome_categoria) VALUES
('Eletrônicos'),
('Periféricos'),
('Automotivo'),
('Livros');

INSERT INTO PRODUTO (id_categoria, nome_produto, preco, estoque) VALUES
(1, 'Smartphone Galaxy S24', 4500.00, 15),
(1, 'Notebook Dell Inspiron', 3800.00, 8),
(2, 'Teclado Mecânico RGB', 250.00, 30),
(2, 'Mouse sem Fio', 120.00, 50),
(3, 'Jogo de Velas de Ignição Corolla', 180.00, 20),
(4, 'Livro de Engenharia de Software', 95.00, 10);

INSERT INTO FORMA_PAGAMENTO (descricao) VALUES
('Pix'),
('Cartão de Crédito'),
('Boleto Bancário');

INSERT INTO PEDIDO (id_cliente, id_endereco, data_pedido, status_pedido) VALUES
(1, 1, '2026-03-15 10:30:00', 'Concluído'),
(2, 2, '2026-03-16 11:00:00', 'Concluído'),
(1, 1, '2026-03-20 16:45:00', 'Pendente'),
(3, 3, '2026-03-22 14:10:00', 'Concluído');

INSERT INTO ITEM_PEDIDO (id_pedido, id_produto, quantidade, preco_unitario) VALUES
(1, 1, 1, 4500.00),
(1, 3, 1, 250.00),
(2, 2, 1, 3800.00),
(3, 5, 2, 180.00),
(4, 4, 2, 120.00),
(4, 6, 1, 95.00);

INSERT INTO PAGAMENTO (id_pedido, id_forma_pagamento, valor_pago, data_pagamento) VALUES
(1, 1, 4750.00, '2026-03-15 10:32:00'),
(2, 2, 3800.00, '2026-03-16 11:02:00'),
(4, 1, 335.00, '2026-03-22 14:12:00');


-- ============================================================
-- OS 10 SCRIPTS AVULSOS + VIEW (Para executar na apresentação)
-- ============================================================

-- 1. Filtro e Ordenação
SELECT nome_produto, preco, estoque FROM PRODUTO WHERE preco > 200.00 ORDER BY preco DESC;

-- 2. Busca por Padrão de Texto (LIKE)
SELECT id_cliente, nome, email FROM CLIENTE WHERE nome LIKE '%Silva%' OR nome LIKE '%Rosa%';

-- 3. Intervalo de Datas (BETWEEN)
SELECT id_pedido, id_cliente, data_pedido, status_pedido FROM PEDIDO WHERE data_pedido BETWEEN '2026-03-15 00:00:00' AND '2026-03-31 23:59:59';

-- 4. JOIN simples (2 Tabelas)
SELECT P.id_produto, P.nome_produto, C.nome_categoria, P.preco FROM PRODUTO P INNER JOIN CATEGORIA C ON P.id_categoria = C.id_categoria;

-- 5. JOIN Múltiplo (4 Tabelas)
SELECT C.nome AS cliente, P.id_pedido, PR.nome_produto, IP.quantidade, IP.preco_unitario, P.status_pedido FROM PEDIDO P INNER JOIN CLIENTE C ON P.id_cliente = C.id_cliente INNER JOIN ITEM_PEDIDO IP ON P.id_pedido = IP.id_pedido INNER JOIN PRODUTO PR ON IP.id_produto = PR.id_produto;

-- 6. Agregação (COUNT e GROUP BY)
SELECT C.nome_categoria, COUNT(P.id_produto) AS total_produtos FROM CATEGORIA C LEFT JOIN PRODUTO P ON C.id_categoria = P.id_categoria GROUP BY C.nome_categoria;

-- 7. Soma e Média (SUM, AVG)
SELECT FP.descricao AS forma_pagamento, SUM(P.valor_pago) AS total_faturado, AVG(P.valor_pago) AS ticket_medio FROM PAGAMENTO P INNER JOIN FORMA_PAGAMENTO FP ON P.id_forma_pagamento = FP.id_forma_pagamento GROUP BY FP.descricao;

-- 8. Agregação com HAVING
SELECT C.nome, COUNT(P.id_pedido) AS total_pedidos FROM CLIENTE C INNER JOIN PEDIDO P ON C.id_cliente = P.id_cliente GROUP BY C.nome HAVING COUNT(P.id_pedido) > 1;

-- 9. Atualização (UPDATE)
UPDATE PRODUTO SET preco = preco * 1.10 WHERE id_categoria = (SELECT id_categoria FROM CATEGORIA WHERE nome_categoria = 'Periféricos');
SELECT nome_produto, preco FROM PRODUTO WHERE id_categoria = 2;

-- 10. Exclusão/Alteração (DELETE e UPDATE)
DELETE FROM PAGAMENTO WHERE valor_pago = 0.00;
UPDATE PEDIDO SET status_pedido = 'Cancelado' WHERE id_pedido = 3;
SELECT id_pedido, status_pedido FROM PEDIDO WHERE id_pedido = 3;

-- VIEW ESTRATÉGICA OBRIGATÓRIA
CREATE OR REPLACE VIEW VW_RELATORIO_EXECUTIVO_VENDAS AS
SELECT C.id_cliente, C.nome AS nome_cliente, C.email, COUNT(DISTINCT P.id_pedido) AS quantidade_pedidos, IFNULL(SUM(PG.valor_pago), 0.00) AS total_gasto FROM CLIENTE C LEFT JOIN PEDIDO P ON C.id_cliente = P.id_cliente LEFT JOIN PAGAMENTO PG ON P.id_pedido = PG.id_pedido GROUP BY C.id_cliente, C.nome, C.email;

-- Consulta da View
SELECT * FROM VW_RELATORIO_EXECUTIVO_VENDAS ORDER BY total_gasto DESC;